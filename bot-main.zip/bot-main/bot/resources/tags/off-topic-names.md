---
embed:
    title: "Off-topic channels"
---
There are three off-topic channels:
- <#291284109232308226>
- <#463035241142026251>
- <#463035268514185226>

The channel names change every night at midnight UTC and are often fun meta references to jokes or conversations that happened on the server.

See our [off-topic etiquette](https://pythondiscord.com/pages/resources/guides/off-topic-etiquette/) page for more guidance on how the channels should be used.

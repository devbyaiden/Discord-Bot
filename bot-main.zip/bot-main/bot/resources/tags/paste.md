---
embed:
    title: "Pasting large amounts of code"
---
If your code is too long to fit in a codeblock in Discord, you can paste your code here:
https://paste.pythondiscord.com/

After pasting your code, **save** it by clicking the Paste! button in the bottom left, or by pressing `CTRL + S`. After doing that, you will be navigated to the new paste's page. Copy the URL and post it here so others can see it.

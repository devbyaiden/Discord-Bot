---
aliases: ["print-return", "return-jif"]
embed:
    title: Print and return
    image:
        url: https://raw.githubusercontent.com/python-discord/bot/main/bot/resources/media/print-return.gif
---
Here's a handy animation demonstrating how `print` and `return` differ in behavior.

See also: `/tag return`
